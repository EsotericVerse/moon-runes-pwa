# Current authority reference — LOC GPT Skills 2.1

Always refresh current implementation and runtime data. This reference is a checklist, not another source of authority.

## Technical source ownership

| Responsibility | Current owner |
| --- | --- |
| Task scope and intentional decisions | User's explicit current instruction; the relevant human content/Scope owner for semantic approvals |
| Application implementation | Current GitHub main |
| Primary canonical runtime records / authorized writes | Supabase PostgreSQL |
| Public read failure fallback | Neon, read-only and only for supported anonymous requests; never a management/auth write fallback |
| Route existence | Next.js filesystem and fixed generic Scope shell |
| Deployment/navigation/Group membership | `silver.scope_registry`, including `parent_scope_id` |
| Scope-to-data table mapping, current management roles | `silver.manage` / actual database policies |
| Write enforcement | Actual RLS and database policies |
| Explanation | Current LOC Canon, maintained docs, not runtime data |
| Retired layer | KM: not in current use and cannot override any of the above |

No AI workflow is a human authority or a substitute for authentication. A Skill can gather evidence, flag a conflict and suggest a patch; permission to run, approve or certify is separate.

## Current structure and invariants

- Scope Group is membership and navigation, not an implicit permission union. Ordinary Groups do not aggregate Search, Culture or Statistics across children. LOC (`loc`) preserves narrowly scoped, **read-only** Culture intersections/source timelines and Statistics totals/shares/trends. LOC Group Search still does not run cross-child full-text retrieval. No merged corpus table.
- Management roles are `scope` (explicitly mapped Scopes) and `admin` (global). RLS remains authoritative. Clerk Auth/Organizations is a proposed future integration, **not** a present third role or deployed source of access rights.
- Galaxy `uid` is canonical record identity; authored text and pure multimedia have distinct representations. Media stores URLs and metadata, not implicit authored body text. Provenance and relation fields are explicit.
- General keyword classes are independent UUID-addressed resources. Confirmed batch classification persists `class_id` and `group_lists` attrs on articles; public Statistics/Culture read these rather than silently reclassifying.
- Public feature flags and `searchable=false` do not by themselves erase a canonical management record.
- Statistics and Search derive exact results through bounded queries; no second stored corpus/ranking authority. FlexSearch is retired from the Current runtime contract.
- Source Refresh uses precise `source_name + source_native_id` bounded delta comparison before approved changes.
- No automatic decision about an author's identity, worth, culture shift, Anchor confirmation or Canon meaning.

## Domain-specific line

LOC is Language Architecture Framework; LunaRunes is a separate authored Symbolic Language. Its fixed semantics and direction grammar are not generic fallback rules. Any Rune66 copy-on-create creates independent keyword data owned by the new Scope.

## Review pattern

State: observed facts → possible inconsistency → responsible owner and rights → proposed minimal change → user approval if required → verification evidence. Never substitute the existence of a Skill for approval.
