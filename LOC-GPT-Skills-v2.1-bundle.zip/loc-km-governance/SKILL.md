---
name: loc-km-governance
description: Audit Current LOC and LunaRunes Canon, authority/decision boundaries, documentation, Scope mappings, terminology and data governance. KM is retired, despite this skill's compatibility name. Use for governance inconsistencies and Authority reviews.
---

# LOC governance and Authority review

This is a CURRENT-state, evidence-based review workflow. The skill's established identifier is kept for compatibility; it does **not** reactivate KM.

## Evidence and precedence

1. Respect the user's explicit instruction and the limits of the granted task. A request for review is not permission to write.
2. Refresh current `main` before repository conclusions; inspect the running schema and current canonical data when a question depends on runtime records.
3. **Supabase PostgreSQL** is the primary canonical runtime store for public reads and authorized writes. **Neon** is a read-only fallback for eligible failed anonymous/public queries; it is not the default writer, a second canonical owner, or an automatic fallback for authentication and management.
4. Next.js filesystem owns routes. The Scope Registry owns deployment and navigation metadata and `parent_scope_id` Group membership; `silver.manage` owns Scope/data table mappings and management role mappings. Database RLS/policies remain the final enforcement for writes.
5. Current Canon and docs explain the architecture but cannot replace runtime evidence. The old KM layer is **not used** in Current; do not silently recreate it. Old commits and archived JSON are historical evidence only when expressly requested.

Read [references/current-authority.md](references/current-authority.md) before a full governance review.

## Authority is not ability

Distinguish:
- **Capability (Skills)**: investigate, compare, identify conflicts, explain findings and draft recommended actions.
- **Governance authority**: who can define semantics, approve an interpretation, authorize a change and accept responsibility for it.
- **Technical authorization**: whether the logged-in user and database role can perform the specific operation.

An AI Skill's ability to classify, inspect or recommend does not grant approval, authorship, Scope administration, a certification decision, or permission to change Canon or data. Keep observations, hypotheses, proposed decisions and approved decisions visibly separate. Never invent an Authority level, certification badge, score or new role. The owner of a semantic Canon decides semantic changes; legitimate Scope managers/admins exercise only their assigned technical permissions. Public visibility, Group membership and a link to a file confer no additional rights.

## Domain identity

- LOC / 月典: **Language Architecture Framework**.
- LunaRunes / 月之符文: independent authored **Symbolic Language**.
- LunaRunes Canon is not a generic LOC Scope default. Rune 66 keywords may be copied into a newly created Scope as independently editable UUID resources, but not kept live-linked or treated as a fallback Canon.
- Canonical Galaxy records, keyword classes, article attrs, media metadata, Scope Registry and explanatory documents have different responsibilities. Do not silently conflate them.

## Governance audit

Check inconsistencies among:
- Current code, runtime Supabase schema/records, repository docs, Scope Registry and `silver.manage`;
- Canon definitions, authored copy, terminology and generic UI localization;
- `class_id` / `group_lists` persisted article attrs versus editable keyword classes (no automatic retroactive reclassification);
- Search's precise bounded retrieval, Culture's time/source analysis, Statistics' live distributions, and Governance's rules;
- LOC's **limited read-only** cross-Scope Statistics and Culture comparison versus **ordinary newly created Scope Groups**, whose Search/Statistics/Culture are Registry overview and navigation only;
- management/public visibility, explicit `scope` and `admin` roles, and database RLS;
- source/provenance fields, and the distinction between media URLs and authored body text.

Group Search does not merge full-text corpora across children, and even LOC's special comparison neither unifies Canon nor grants Group-wide write authority.

## Query, safety and change discipline

- Filter and count in PostgreSQL first; select only needed columns, page large results in bounded requests. No select-all-then-slice and no duplicate canonical corpus, cache or ranking authority.
- Never reintroduce FlexSearch as an active runtime authority or KM as a Current database. Do not infer nonexistent fields or cross-Scope permissions.
- Do not create tables, RLS policies, roles, mappings, external accounts or certifications autonomously.
- For **review-only** requests, report findings and stop.
- For an explicit edit request, inspect the current exact target, make the minimal authorized change, preserve unrelated work, and verify the resulting state. Risky schema/permission/Canon mutations require explicit user instruction for the specific change, not an inference from a Skill's general purpose.
- Explicitly note when a result depends on unverified runtime permissions or was merely suggested rather than executed.

## LunaRunes invariants

Unless the owner has explicitly established a newer canonical rule: normal draw pool 01–66; 第零符 德 excluded from normal draws; four directions 正位/半正位/半逆位/逆位; 43 水 means Water, while Flow belongs to 氣; 65 玄 means Chaos, not 虛; 玄逆位 describes gradual integration into recognizable order; 日 is eclipse / expected accident / human-caused incident, not generic light/time; 月 expresses the dark side; 誤 means Error; card moon phase and real moon phase are separate fields. Draw interpretation remains rule/grammar based, not a made-up numerical semantic score.

## Output contract

Report the evidence and actual authority consulted, exact conflicts and impacted paths/records, a narrow recommended remedy, what was actually changed (if anything), and owner-only decisions awaiting approval. Never call a proposed decision "approved" or a check "certified" without an explicit real approval process.
