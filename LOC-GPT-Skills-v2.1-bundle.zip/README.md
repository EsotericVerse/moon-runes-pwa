# LOC GPT Skills v2.1

Current, portable GPT Skills bundle for LOC / 月典 and LunaRunes / 月之符文.

Published 2026-10-09. Version 2.1 updates the 2026-10-01 v2.0 governance baseline without renaming existing skill identifiers.

Included:
- `loc-km-governance` — Current Canon, Authority/decision boundaries, data responsibility and consistency audits. Its name is retained for compatibility; **KM is retired**.
- `loc-repo-health-check` — Current repository, data/query, static asset and release audits.

Current primary data authority is **Supabase PostgreSQL**; Neon is a restricted **public read-only fallback**. Human approvals and the actual `scope`/`admin` authorization/RLS are independent of AI Skills.

The bundle does not include the LunaRunes-specific `lunarunes-semantic-group-classifier`.

Usage: install the appropriate Skill directory in a Skill-capable AI environment; review the file's frontmatter and references; invoke a review using a concrete Current task. Installation/use and live data permissions are **not** implied by downloading the ZIP.

Historical v1.0 and v2.0 ZIPs remain available for backward compatibility, but are not the Current governance baseline.
