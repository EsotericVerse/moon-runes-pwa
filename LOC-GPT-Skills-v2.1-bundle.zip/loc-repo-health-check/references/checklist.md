# Current repository review checklist — Skills 2.1

Use live code, canonical database and evidence rather than this file as a second authority.

- [ ] Refresh main and selected files immediately before review/edit.
- [ ] Routes from Next filesystem and generic Scope shell; Scope Registry deployment/Group membership; `silver.manage` Scope/table/role mappings.
- [ ] Supabase canonical primary read/write; Neon only limited anonymous read failure fallback; never automatic auth/write failover.
- [ ] Current RLS and `scope`/`admin` role enforcement; no new role inferred from Group, Skill or public visibility.
- [ ] LOC's bounded cross-Scope Culture/Statistics exception; ordinary Group overview/navigation; Group Search never cross-corpus.
- [ ] Galaxy, media metadata/URLs, relation and provenance fields not conflated; no duplicated corpus or ranking snapshot.
- [ ] UUID keyword classes independent; `class_id`/`group_lists` persisted attr contract; no silent public reclassification.
- [ ] No active KM/FlexSearch reliance from historical Skill instructions.
- [ ] Search / Culture / Statistics precise projected SQL, COUNT, date filters and bounded pagination; no full-body preload for charts.
- [ ] LunaRunes rules remain LunaRunes-specific, using selected IDs/directions/types.
- [ ] UI/CSS ownership, BlockNote editing, accessibility, responsive and error/loading/empty states.
- [ ] Dependences, lockfile, imports, static file consumers, CI and deployment consistency.
- [ ] Skills ZIP file, static-copy script, output filename and live Supabase home Page Block link/version agree.
- [ ] Relevant verify scripts actually run (report failures); build and Playwright as needed.
- [ ] Proposed Authority decisions are recommendations, not AI-granted certification or data modification approval.
