---
name: loc-repo-health-check
description: Inspect the Current LOC repository for route, data adapter, dependency, CSS/JS, query, static download, deployment and release regressions; report actionable evidence without assuming permission to change code.
---

# LOC repository health check

Audit the actual Current implementation, not retired architecture. Read [references/checklist.md](references/checklist.md) for full audits.

## Baseline

1. Refresh Current `main`, `package.json`, the relevant Current architecture/Canon/release documents and actual code paths.
2. Identify consumer routes, owner modules, CSS owners, tests and public downloads. Do not assume a feature is active because an old README or ZIP mentions it.
3. If runtime data matters, inspect the actual **Supabase primary** schema/records. **Neon is an eligible public read-only fallback**, not default data authority or a management write failover.
4. Distinguish verified results, source-only observations and untested behaviors. A passing download-link check does not prove that an AI Skill was installed or executed.

## Ownership

- `app/`: Next.js routes and modules; `assets/`: runtime assets; `pics/`: approved images; `docs/`: maintained Current docs; `governance/`: current governance state; `scripts/` and `tests/`: verification.
- Next filesystem owns route existence; the Scope Registry owns navigation/deployment metadata and Group membership; `silver.manage` handles table/Scope mapping. Do not introduce a second registry.
- Keep authored content and LunaRunes Canon outside generic UI-copy localization. Ordinary Scope Group pages are overview/navigation only; LOC uniquely retains bounded read-only Statistics/Culture comparisons.
- Respect the existing BlockNote/Page Block editor rather than inventing a parallel editor or changing the theme token owner.
- Write roles remain `scope` and `admin`; RLS is final. Planned Clerk integration is not an active authorization implementation.

## Query and data checks

Flag full table preloads sliced in JS, unnecessary body loads, repeated fallbacks, table list scans for known mappings, duplicated caches/corpora, fabricated ranking tables, hidden keyword reclassification and full Rune direction loads for a single draw.

Ensure Search, Culture and Statistics use precise PostgreSQL filters, COUNT and bounded pagination/incremental loading. Keep media metadata separate from authored text. No FlexSearch runtime dependency or KM reactivation unless current evidence and explicit owner instruction supersede existing contracts.

General Scope keyword classes must remain independently editable. Confirmed article attrs (`class_id`, `group_lists`) are consumed as persisted labels instead of recalculated during every public view. Ensure Source Refresh is bounded by source native identity and makes no unapproved writes.

## UI, packages and static assets

- Check stylesheet ownership, responsive hierarchy, focus/keyboard access, reduced-motion handling, contrast and empty/loading/error presentation.
- Cross-check `package.json`, actual imports, lockfile, build tool and active consumers before declaring a dependency dead.
- For every download, confirm **repository ZIP exists**, `scripts/copy-static-assets.mjs` includes it, output contains it, and homepage `loc_blocks` URL/version matches. The homepage Skills copy is database-owned; a repository fixture or Playwright expectation is not the live copy.
- Do not overwrite historic released ZIPs; publish incremented release bundles under new names.

## Verification

Use the narrowest relevant `verify:*` scripts, then `npm run verify`, `npm run build`, and Playwright when their scope warrants. Distinguish scripts inspected from scripts actually run. A green test is not evidence that a live database content edit deployed.

## Mutation discipline

Review only means **no write**. For authorized repairs: refresh target SHA/state just before editing, touch only the owned paths/data, preserve unrelated changes, run relevant checks, verify any content update at its true source and report what remains unverified. A Skill cannot approve its own fixes or expand administrative rights.

## Report

Provide exact affected files/queries, severity and user impact, observed evidence, minimum correction, verification results and unresolved risks. Do not claim zero defects without tests or "certified" status without a separately approved procedure.
