---
name: loc-repo-health-check
description: Review the Current LOC repository for route, module, query, performance, dependency, CSS/JS ownership, static-asset, deployment and release-health problems. Use for repository audits, release readiness, stale-code cleanup, regression checks and narrowly scoped remediation.
---

# LOC repository health check

Audit the repository that exists now. Do not reconstruct a retired architecture and do not infer missing components from old commits.

## Establish the baseline

1. Refresh Current main.
2. Read `package.json` and the Current governance/release documents relevant to the task.
3. Identify the exact route, feature, stylesheet, script or data path involved.
4. If runtime behavior depends on data shape or counts, inspect Current Neon instead of guessing from code comments or historical schemas.
5. Use history only for an explicitly requested recovery, provenance check or regression comparison.

Read [references/checklist.md](references/checklist.md) before a full repository audit.

## Repository contract

Expect the Current ownership model:

- `app/` — Next.js routes, UI and feature modules;
- `assets/` — runtime/domain assets;
- `docs/` — Current architecture/design/governance documents;
- `governance/` — active repository-governance state;
- `pics/` — approved site images;
- `scripts/` — Current build and verification utilities;
- `tests/` — browser/accessibility tests.

A Current file should have a consumer or an explicit governance/design responsibility. Duplicate Current sources are a defect, not a backup strategy.

## Route and UI checks

- Next filesystem owns route existence.
- Global navigation has one formal implementation; page-local controls are not a second global NAV.
- Scope Registry may provide URL/navigation metadata but must not become data authority.
- Fixed UI copy may be centralized; authored Galaxy text and LunaRunes Canon must not be rewritten by localization.
- Presentation-only static rules belong in CSS; JavaScript should own dynamic behavior, not duplicate static styling.
- Check desktop, tablet and mobile hierarchy, focus states, keyboard access, reduced motion and failure/loading states where relevant.

## Query and performance checks

Flag any pattern that:

- selects an entire large dataset and slices in JavaScript;
- repeats the same fallback query multiple times;
- scans table lists to discover known Current tables;
- builds a second corpus cache/projection/ranking authority;
- loads full body text when only date/title/uid is needed;
- loads all Rune directions or all `runes_etc` types for one result;
- lets FlexSearch perform full-corpus authority work;
- blocks all Scopes because one Scope is missing optional birth/Anchor/config data.

Prefer precise SQL/Neon filtering, COUNT and pagination. Treat waits above roughly one second in ordinary 30k-row-class queries as a performance smell that deserves evidence-based investigation.

## Static assets and deployment

For any public download/image referenced by the UI:

- confirm the repository file exists;
- confirm the postbuild/static-copy path publishes it;
- confirm the public href matches the copied filename;
- remove retired asset references only when no Current consumer remains.

Do not leave a working UI link pointing to a file omitted from static output.

## Dependencies and modules

Compare imports and feature use against `package.json`.

Check for:

- unused or duplicate packages;
- missing declared dependencies;
- retired modules still imported;
- duplicate CSS presentation layers;
- old Registry/V2/legacy code being treated as Current authority;
- dead files left after a replacement architecture is complete.

Do not remove a package or file solely because a text search is empty if runtime/config/build usage has not been checked.

## Verification

Prefer the repository's Current scripts. Typical checks may include:

- `npm run verify`
- `npm run build`
- focused `verify:*` scripts from Current `package.json`
- Playwright when UI behavior is in scope.

Run the narrowest relevant checks first. A failed check is evidence to investigate, not permission to broaden the task.

## Mutation discipline

If the user requests a review only, do not write.

If the user requests a fix:

- refresh the exact target just before writing;
- patch only the requested scope;
- preserve unrelated concurrent user edits;
- do not create new tables, RLS, caches, projections or architectural layers as a shortcut;
- do not delete historical assets unless they are confirmed retired from Current and deletion is within scope;
- verify after the write and report the exact changed paths.

## Result

Report concrete evidence, affected path/function, user impact, the smallest remediation and verification status. Separate confirmed defects from optional cleanup.
