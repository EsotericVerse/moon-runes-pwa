# Current repository health checklist

Use this as a checklist, not as authority over live Current main.

## Baseline

- Refresh main immediately before conclusions and again before writes.
- Read Current `package.json`.
- Read the Current Canon/UI/navigation/directory/release document relevant to the task.
- Inspect Current Neon for data-dependent claims.

## Routes and navigation

- Route exists in the Next filesystem.
- Global NAV is not duplicated.
- Scope Registry stays within deployment/navigation metadata responsibility.
- Public URL and canonical domain/mount are consistent.

## Data boundaries

- Neon remains SSOT.
- `silver.manage` owns Scope/table mapping.
- No second corpus authority, ranking snapshot or hidden fallback dataset.
- Public visibility and management visibility are not conflated.
- `searchable=false` does not make a canonical management record disappear.

## Query shape

- Precise fields only.
- Filter/COUNT before page retrieval.
- OFFSET/LIMIT or Current pagination contract.
- No select-all-then-slice.
- No unnecessary full-body load for list/timeline views.
- Rune queries load only requested IDs/directions/types.

## Search

- Neon handles deep authoritative filtering and pagination.
- FlexSearch handles narrowed lexical acceleration only.
- No semantic rendering unless the architecture explicitly changes.
- General Scopes do not borrow LunaRunes Canon/keywords as fallback.

## Culture

- Multi-Scope time range uses intersection.
- Missing optional Scope data skips rather than blocks the whole result.
- Galaxy aggregation happens after time intersection.
- Content loads incrementally.
- Anchor suggestions remain suggestions and require enough eligible data.

## Statistics

- Live calculation from canonical data.
- Optional time range works.
- Multimedia is counted in appropriate source/statistical contexts without inventing body text.

## UI and CSS

- Static presentation is in CSS where practical.
- JavaScript owns state/behavior.
- No retired visual architecture CSS remains after its component is removed unless another consumer exists.
- Responsive, keyboard, focus, reduced-motion and contrast behavior remain intact.

## Static/public files

- Referenced file exists.
- Static copy/postbuild includes it.
- Link filename matches exactly.
- Retired public asset references are gone.

## Release

- Run focused verify scripts.
- Run full `npm run verify` when release-wide confidence is required.
- Run `npm run build` when route/build/static-output changes are in scope.
- Use Playwright for interaction/regression work.
- Treat unresolved failures as blockers rather than hiding them behind a version bump.
