# Current authority reference

This reference is a v2.0 baseline. Always refresh the live repository and database before treating versioned details as Current.

## Authority split

- User's explicit Current instruction: highest task-level authority.
- Current main: implementation authority for application code and repository structure.
- Current Neon: runtime canonical data authority.
- Next filesystem: route authority.
- Scope Registry: deployment/navigation metadata only.
- `silver.manage`: data Scope and Galaxy/Time table mapping.
- Current docs/Canon: maintained explanatory governance.
- KM: reusable knowledge only; never a second route/data/permission/Canon authority.
- Historical/archive material: non-authoritative unless explicitly requested for recovery or comparison.

## Current LOC data rules

- Galaxy `uid` is the canonical record identity.
- Blank body text is not a valid text work.
- Pure multimedia remains media; do not invent an empty Galaxy body.
- `source_id`, `target_id`, `ref_id` and `galaxy_link` preserve relations.
- `source_native_id` preserves source-platform identity.
- Media metadata may participate in Search, Culture and Statistics, but is not authored body text.
- Statistics are calculated live; do not create a second stored ranking authority.
- Management can read canonical records even when public feature flags are off or `searchable=false`.
- Galaxy edits update `UpdateTime`.

## Shared features

- Culture: time intersection, density, source grouping and user-confirmed Anchor workflow.
- Statistics: live distribution with selectable time ranges.
- Search: precise lexical/metadata retrieval; no semantic rendering.
- Governance: public rules plus management boundaries.

Culture multi-Scope comparison uses intersection, not union. Anchor suggestions require enough eligible data and remain suggestions until a user confirms them.

## Query rules

- Query only what the current function needs.
- COUNT/filter first, then OFFSET/LIMIT.
- General page size is 10; Rune list contract is 16 unless Current code says otherwise.
- Do not pull the entire corpus to the client and slice there.
- FlexSearch may accelerate narrowed local lexical work but never replaces Neon as SSOT.

## LunaRunes runtime

- Canonical runtime tables: `silver.runes`, `silver.runes_etc`.
- A draw reads only selected Rune IDs, selected directions and requested data type.
- Five-second ritual and per-card random selection are intentional Current behavior unless the owner changes them.
- Draw grammar is structural and is not replaced by numeric semantic scoring.

## Neutrality

LOC may expose trajectories, distribution changes and risk signals. LunaRunes may describe symbolic states. Neither should make the user's identity, value or life decision for them.
