---
name: loc-km-governance
description: Audit LOC and LunaRunes authority, Canon, KM, Registry, Base66, terminology, data ownership and Current-state consistency. Use when checking whether documentation, UI copy, repository rules, Neon data responsibilities, LunaRunes semantics or governance artifacts contradict the Current system.
---

# LOC KM governance

Treat this as a Current-state governance workflow, not a historical reconstruction workflow.

## Start with authority

1. Read the user's current explicit instruction first.
2. Refresh Current main before making repository claims or edits.
3. Inspect Current Neon when the question depends on runtime data, table fields, mappings or counts.
4. Use Current Canon and Current governance documents as explanatory references, not as a second runtime authority.
5. Treat KM as a reusable knowledge layer only. KM must never override Current main or Current Neon.
6. Historical commits, archived files, old registries and retired JSON may be used only when the user explicitly asks to recover a known asset or compare history. Never revive historical architecture by default.

Read [references/current-authority.md](references/current-authority.md) before a governance audit.

## Core identity

Keep these identities separate and exact:

- LOC / 月典 — Language Architecture Framework.
- LunaRunes / 月之符文 — Symbolic Language.
- LunaRunes rules do not become general LOC Scope defaults.

Do not convert symbolic-language definitions into global system rules, and do not let generic UI localization rewrite authored works or LunaRunes Canon.

## Governance checks

Check for contradictions across:

- Canon and Current documentation;
- repository code and route ownership;
- Scope Registry responsibility;
- `silver.manage` Scope/table mapping;
- Neon canonical tables and runtime queries;
- public UI copy versus authored content;
- LunaRunes names, directions, special semantics and draw grammar;
- Search, Statistics, Culture and Governance responsibility boundaries;
- management visibility versus public visibility;
- active files versus retired or duplicated sources.

When a conflict exists, identify the exact conflicting sources and resolve toward the Current authority instead of preserving both versions.

## Data and schema boundary

Do not autonomously:

- create tables, caches, projections or duplicate corpora;
- alter RLS, grants, roles or database permissions;
- create a second Scope/data registry;
- reintroduce retired JSON as runtime authority;
- invent missing fields, mappings, routes, keywords or fallback semantics.

If a user explicitly requests a schema or permission change, inspect the actual Current schema first and state the exact mutation before applying it.

## Query governance

Require precise queries:

- narrow in SQL/Neon first;
- use COUNT/filter before OFFSET/LIMIT pagination;
- do not `select *` for a full corpus and slice in JavaScript;
- do not preload unused Rune directions or `runes_etc` types;
- keep FlexSearch as a narrowed lexical surface layer, never corpus authority or semantic renderer.

## LunaRunes invariants

Preserve Current fixed rules unless the user explicitly supplies a newer authoritative change:

- normal draw pool: 01–66;
- 第零符 德 is not in the normal draw pool;
- four directions: 正位 / 半正位 / 半逆位 / 逆位;
- 43 水 = Water, not Flow;
- flow belongs to 氣;
- 65 玄 = Chaos and is not 虛;
- 玄逆位 is the gradual integration of previously inexpressible rules into recognizable order;
- 日 is eclipse / expected accident / human-caused incident semantics, not generic light/time;
- 月 is the dark side;
- 誤 = Error;
- card moon phase and real moon phase are separate fields.

## Change discipline

If the user asks only for review, report findings and stop.

If the user asks for edits:

- refresh the exact target immediately before writing;
- make the smallest patch that satisfies the request;
- do not rewrite neighboring copy or architecture for consistency unless explicitly requested;
- preserve unrelated user edits;
- verify the resulting Current state after the write.

## Result

Return concise findings with:

- the Current authority used;
- the exact inconsistency or risk;
- the smallest correct action;
- any unresolved item that requires owner confirmation.

Do not score the project, invent a new Canon, or preserve a wrong historical state merely because it once existed.
