# LOC GPT Skills v2.0

Current bundle for LOC / LunaRunes repository work.

Created for the Current architecture in which:

- LOC / 月典 is the Language Architecture Framework.
- LunaRunes / 月之符文 is an independent Symbolic Language.
- Current main + Current Neon are the implementation authority.
- Next.js owns routing, React owns UI, and PostgreSQL (Neon) owns runtime canonical data.

Included skills:

- `loc-km-governance` — authority, Canon, KM, terminology and data-governance consistency.
- `loc-repo-health-check` — Current repository, route, query, dependency, static-asset and release health.

The bundle intentionally does not include the older `lunarunes-semantic-group-classifier`; that is a LunaRunes-specific skill rather than a general LOC GPT Skill.

Version: 2.0
Date: 2026-10-01
