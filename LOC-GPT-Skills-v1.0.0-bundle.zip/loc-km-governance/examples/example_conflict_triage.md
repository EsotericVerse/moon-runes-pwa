# Example: Governance Conflict Triage
Input: UI says `玄 = Mystery`; Base66/current rule says `玄 = Chaos`.

Triage: owner=runes; authority=current Canon/LunaRune66; severity=C3; action=CORRECT downstream projection then search stale current-facing `Mystery`; preserve old translation only as labeled history if meaningful.
Do not average meanings or present them as equal alternatives.
