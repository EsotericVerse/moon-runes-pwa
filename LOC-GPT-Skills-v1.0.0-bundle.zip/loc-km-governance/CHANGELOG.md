# Changelog
## 1.0.0
- Rebased on current LOC Language System Model theory.
- Replaced v0.1 LOC distribution assumptions with current public guide + semantic backend domains.
- Replaced LunaRune64 mother-source assumptions with LunaRune66 authority.
- Added model/implementation boundary, provenance/lifecycle, Evolution integrity, structured output schema, and executable first-pass validator.
- Preserved v0.1 intent while removing obsolete architecture assumptions.

## 0.1.x
- Original workflow-oriented skill generation.
