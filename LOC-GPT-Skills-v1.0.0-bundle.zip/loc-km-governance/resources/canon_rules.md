# LOC Current Canon Rules — v1 Skill Baseline

## Identity
- LOC = Luna Codex = 月典
- LunaRunes = 月之符文
- Luna Codex is not the English name of 月之符文
- LOC = Language System Model
- LunaRunes = Symbolic Language Model reference implementation

## Data authority
- Current structured rune mother source: `LunaRune66.xlsx`
- Derived JSON/JS/search/API/UI do not outrank it
- Current user-confirmed governance may supersede stale repository text and must then be propagated explicitly

## LunaRunes constants
- draw set 66; rune 0 德 is reference/governance anchor and not drawable
- 65 玄 = Chaos; 66 命 = Fate; formal 65/66 group = 特殊 (Special)

### Eight fixed groups
1. 靈魂: 靈、魂、彩、憶、界、域、鏡、核
2. 連結: 向、斷、封、鍊、啟、分、悟、誤
3. 生命: 生、老、病、死、心、愛、語、韻
4. 自然: 樹、花、葉、草、根、種、實、枝
5. 礦物: 金、玉、晶、地、石、鑽、礦、塵
6. 元素: 光、暗、水、火、風、土、雷、氣
7. 秩序: 日、月、星、辰、明、時、空、因
8. 無序: 福、禍、無、夢、幻、緣、虛、果

## Fixed semantic disambiguation
- 無=blank; 虛=void; 空=space; 氣=air; 暗=shadow; 玄=chaos; 誤=error
- 水=Water, not Flow
- 實=fruit; 果=result
- 時=time; 緣 may carry opportunity/occasion semantics
- 鍊 is the rune name; do not normalize it into 鍛鍊

## Orientation
正位 / 半正位 / 半逆位 / 逆位

## Grammar
- 2-card: 因→果
- 3-card: 源→轉→合
- 5-card: 過去→現在→未來顯化→周圍環境→自己心境
- OW3gs: 1–6 因的描述層; 7–11 果的判定層; read 7–11 first, then 1–6; lunar-phase interaction is lower-weight modifier

## Current LOC1–8 public guide
1 LunaRunes / 月之符文
2 Context / 脈絡
3 Music / 音樂
4 Literary / 文字創作
5 MultiMedia / 多媒體
6 Methodology / 方法論
7 Algorithm / 演算法（知識庫）
8 Evolution / 推演

Backend implementation should use semantic domains rather than LOC numbers as canonical ownership taxonomy.
