# LOC KM Governance Final Checklist

## Model identity
- [ ] LOC not mislabeled as LunaRunes
- [ ] Luna Codex = LOC / 月典
- [ ] LunaRunes = 月之符文
- [ ] Language System Model used consistently for current theory baseline
- [ ] LunaRunes described as Symbolic Language Model reference implementation when relevant

## Rune authority
- [ ] `LunaRune66.xlsx` current mother source
- [ ] no current `LunaRune64.xlsx` authority claim
- [ ] 65玄 / 66命 / 特殊 group correct
- [ ] 0德 not drawable
- [ ] 水 != Flow; 玄 != Mystery
- [ ] 鍊 not polluted by 鍛鍊 wording

## Domain ownership
- [ ] new backend ownership/classification uses semantic domains
- [ ] Graph=context; Graph traversal/RAG=knowledge where applicable; time/trend=evolution
- [ ] original text separated from derived governance interpretation

## Source/lifecycle
- [ ] generated layer does not overwrite authority
- [ ] provenance retained
- [ ] historical records not silently rewritten
- [ ] superseded/tombstoned records identify replacement where possible

## Synchronization
- [ ] upstream source first
- [ ] registries/core projections synchronized
- [ ] search/FAQ/UI downstream synchronized
- [ ] deleted/renamed paths no longer referenced

## Evolution
- [ ] evolution claims have time-aware evidence
- [ ] version changes alone not called evolution

## Reporting
- [ ] verified/inferred/historical/unverified separated
- [ ] destructive actions documented
