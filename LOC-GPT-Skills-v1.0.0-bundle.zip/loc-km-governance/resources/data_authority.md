# LOC Data Authority and Lifecycle

Authority chain: `Authority → Registry → Reference/Core Projection → Search/Generated → Consumer`.
Consumers include UI, API, analysis, agent/Skill responses and caches.

## Cross-domain rule
A domain may reference, consume, analyze, or propose changes to another domain's authoritative record, but must not overwrite its canonical ownership.

Key boundaries: Graph semantics=context; retrieval/RAG/Graph traversal=knowledge; time/period/trend/trajectory=evolution; original authored text=literary; governance/value/style interpretation=governance; rune semantics=runes.

## Lifecycle
proposed, under_review, active, disputed, restricted, amended, superseded, withdrawn, rejected, tombstoned.

## Minimum audit evidence
object ID/path, action, before, after, reason, evidence refs, change time, review state, replacement/superseding ID.

## Historical integrity
Original evidence is preserved. Later interpretations may supersede prior interpretations but must not silently rewrite historical records.

## Evolution integrity
Do not confuse synchronization with semantic evolution. Evolution requires time-aware evidence of changing state, relation, trend, trajectory, interpretation, or output.
