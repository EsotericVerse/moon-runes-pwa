# LOC Language System Model — Skill Reference

## Current top-level definition
LOC (Luna Codex / 月典) is governed here as a **Language System Model**. It models language as a reusable system rather than isolated strings.

Operational chain:
`language units → context/relations → representations/works → methodology → algorithms/knowledge → temporal evolution`

Known technologies (JSON, FastAPI, search, RAG, Graph, rules, embeddings, scripts) are valid implementation components. Novelty at every layer is not required; the model claim rests on coherent reusable system behavior and boundaries.

## Reference implementation
LunaRunes is the primary **Symbolic Language Model reference implementation** used to demonstrate LOC: bounded Base66 vocabulary, governed semantics, groups, orientations, grammar, context relations, derived works, algorithms, and temporal/evolution evidence.

## LM abbreviation
Within LOC material, `LM` may mean **Language System Model** after definition. Public technical material should disambiguate on first use because the broader AI field commonly uses LM for statistical language model.

Recommended first use: `LOC is a Language System Model (LM).`
Recommended LunaRunes form: `LunaRunes is a Symbolic Language Model reference implementation of LOC.`

## Model vs implementation vs skill
- LOC — model / reusable conceptual-governance structure
- LunaRunes — reference implementation / symbolic LM instance
- LOC Skills — callable workflows/capabilities operationalizing the model
- API/UI/MCP/agents — delivery surfaces, not the model itself

## Feasibility evidence
Prefer complete chains: language units; source authority; context/Graph; reusable methodology/grammar; executable algorithms; stable structured outputs; time/evolution behavior; independent delivery surface.
