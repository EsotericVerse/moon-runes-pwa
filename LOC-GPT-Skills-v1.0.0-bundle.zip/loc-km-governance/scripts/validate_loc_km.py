#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
text_ext={'.md','.html','.js','.json','.py','.txt','.yml','.yaml'}
patterns={
 'legacy_mother_source': re.compile(r'LunaRune64\.xlsx',re.I),
 'legacy_mystery': re.compile(r'玄\s*[=:：]\s*(?:Mystery|mystery)'),
 'legacy_water_flow': re.compile(r'(?:水\s*[=:：]\s*Flow|43\s+水.*Flow)',re.I),
 'legacy_loc_map': re.compile(r'LOC1\s+(?:Lots|抽籤)|LOC8\s+(?:Life|生活)',re.I),
}
results=[]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in text_ext: continue
    try: s=p.read_text(encoding='utf-8')
    except Exception: continue
    if p.suffix.lower()=='.json':
        try: json.loads(s)
        except Exception as e: results.append({'type':'invalid_json','path':str(p.relative_to(root)),'detail':str(e)})
    for name,rx in patterns.items():
        for m in rx.finditer(s):
            results.append({'type':name,'path':str(p.relative_to(root)),'line':s.count('\n',0,m.start())+1,'match':m.group(0)[:120]})
print(json.dumps({'root':str(root),'finding_count':len(results),'findings':results},ensure_ascii=False,indent=2))
