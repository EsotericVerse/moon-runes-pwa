---
name: loc-km-governance
description: Govern, audit, migrate, synchronize, and validate LOC knowledge assets against the current LOC Language System Model, LunaRunes Base66 authority, semantic domains, provenance, lifecycle, and evolution rules.
---

# LOC KM Governance

**Skill version:** 1.0.0  
**Theory baseline:** LOC Language System Model / Canon 1.0 generation

## Purpose
Use this skill to govern LOC knowledge, documentation, structured data, registries, terminology, derived indexes, and historical material without allowing stale or lower-authority content to overwrite current definitions.

This is a LOC-native governance skill. It reasons through:
`Source / Canon → Registry → Context / Graph → Methodology → Algorithm / Knowledge → Evolution → Consumer`

Use when the user asks to整理、同步、清理或重構 LOC KM；檢查 Canon、README、docs、HTML、JSON、registry、FAQ/RAG；修正 Base66、Grammar、Context、Graph、Evolution、provenance、lifecycle、rights boundary；清除舊版術語污染或過時 projection；或做跨 domain governance audit。

Do not use this as the primary workflow for repository runtime/PWA health (use `loc-repo-health-check`), creative writing, divination interpretation itself, or model-theory invention without evidence/user confirmation.

## Model Boundary
- **LOC / Luna Codex / 月典** = **Language System Model (LM)**.
- **LunaRunes / 月之符文** = a **Symbolic Language Model reference implementation** of LOC.
- `LM` may abbreviate *Language System Model* after explicit definition; do not silently rewrite it to conventional statistical Language Model.
- LOC1–8 are a human-facing functional guide / standard skeleton. Backend engineering uses semantic domains rather than LOC numbers as primary taxonomy.
- The underlying architecture/framework remains part of LOC, but is not the current top-level name.

See `resources/loc_model.md`.

## Semantic Domains
Use backend domains: `runes`, `context`, `music`, `literary`, `media`, `governance`, `knowledge`, `evolution`, `global`.
Do not introduce new backend dependencies on LOC1–LOC8 merely for classification. Legacy fields may remain for compatibility.

## Authority Model
Default authority flow:
`Author-confirmed current rule / Canon → Mother source → Domain registry → Core projection → Search/generated index → API/UI/analysis → historical material`

For LunaRunes rune semantics:
1. current user-confirmed fixed rules / current Canon
2. `LunaRune66.xlsx`
3. governed rune/core registries and projections
4. generated JSON / search index / API result
5. public explanatory text
6. historical/archived material

A lower layer may reference or analyze an upper layer; it must not overwrite it.

## Critical Current Constants
- `LOC = Luna Codex = 月典`
- `LunaRunes = 月之符文`
- LunaRunes draw set = **66**
- Rune 0 = **德 (De)**, author/reference/governance anchor; not drawable
- 1–64 = eight fixed groups
- 65 = **玄 = Chaos**
- 66 = **命 = Fate**
- formal group for 65/66 = **特殊 (Special)**
- orientations = 正位 / 半正位 / 半逆位 / 逆位
- `無 = blank`; `虛 = void`; `空 = space`; `氣 = air`; `暗 = shadow`; `玄 = chaos`; `誤 = error`
- `水 = Water`, not Flow
- `鍊` must not be normalized into `鍛鍊`

Treat contradictory current-facing material as governance defects unless explicitly marked historical.

## LOC1–8 Public Guide
1. LunaRunes / 月之符文
2. Context / 脈絡
3. Music / 音樂
4. Literary / 文字創作
5. MultiMedia / 多媒體
6. Methodology / 方法論
7. Algorithm / 演算法（知識庫）
8. Evolution / 推演

Do not use the old Lots/Game/Resonance/Text Architecture/Life mapping as current truth.

## Governance Workflow
### 1. Scope
Identify affected domains/surfaces. Do not broaden a local fix into a global rewrite unless consistency requires it.

### 2. Inventory
Record path/ID, domain owner, authority, lifecycle, provenance, generated-vs-authored state, dependencies and consumers.

### 3. Normalize the task into model operations
Classify as identity/terminology, source authority, context/relationship, methodology, algorithm/knowledge, temporal/evolution, rights/provenance, or repository projection synchronization.

### 4. Compare against authoritative evidence
Never infer authority from recency alone. Prefer explicit current confirmation and governed sources.

### 5. Classify conflicts
- **C0** aligned
- **C1** wording drift / harmless alias mismatch
- **C2** structural or ownership mismatch
- **C3** Canon/model contradiction or stale authority takeover
- **C4** provenance/lifecycle violation capable of corrupting downstream model behavior

C3/C4 examples: current `LunaRune64.xlsx` authority; Luna Codex used as 月之符文 English name; 65/66 reversed; `玄=Mystery`; `水=Flow`; new backend taxonomy based on LOC1–8; generated/search data overwriting Canon; historical interpretation silently rewritten.

### 6. Decide lifecycle action
KEEP / CORRECT / MERGE / REDIRECT / ARCHIVE / SUPERSEDE / TOMBSTONE / DELETE / REGENERATE.
Prefer governed tombstone/archive when historical evidence would otherwise be lost.

### 7. Apply upstream-first
1. authoritative source/rule
2. registry/stable structured record
3. core projection
4. search/generated data
5. API/UI/public copy
6. cache/derived outputs

Do not hand-edit generated data when a generator is authoritative.

### 8. Validate boundaries
- Graph semantics owner = `context`
- Graph RAG/retrieval may = `knowledge`
- time/trend/trajectory = `evolution`
- raw authored text = `literary`; governance interpretation remains a separate derivative
- LunaRunes-specific evolution is not conflated with generic LOC Evolution

### 9. Preserve evidence/history
Record before, after, reason, evidence refs, lifecycle state and replacement ID where practical.

### 10. Final validation
Use `resources/km_checklist.md`. With a local checkout, run `scripts/validate_loc_km.py <repo-root>` as a deterministic first pass; its output is evidence, not final semantic judgment.

## Evolution Rule
Evolution is observable time-aware model change, not version-number change.
Look for: `new source/event → context/relationship changes → period/trend/trajectory changes → later analysis/output differs`.

## Output Contract
Return: scope; authoritative evidence; conflicts/severity; changes; downstream sync; model/evolution implications; unverified items. For structured use follow `schemas/km_audit_result.schema.json` where practical.
Always separate **verified**, **derived/inferred**, **historical**, **unverified**.

## Action Style
When direct execution is clearly authorized, perform safe changes without repeated confirmation. Preserve unique history before destructive actions.

## References
- `resources/loc_model.md`
- `resources/canon_rules.md`
- `resources/data_authority.md`
- `resources/km_checklist.md`
- `examples/example_model_migration.md`
