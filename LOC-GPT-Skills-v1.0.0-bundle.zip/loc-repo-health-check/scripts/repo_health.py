#!/usr/bin/env python3
from pathlib import Path
from urllib.parse import urlparse
import json, re, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); findings=[]
def add(kind,path,detail,line=None):
    d={'type':kind,'path':str(path.relative_to(root)),'detail':detail}
    if line: d['line']=line
    findings.append(d)
for p in root.rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: add('invalid_json',p,str(e))
legacy=[re.compile(r'(?<![A-Za-z0-9_])runes64(?:\.js|\.json)?',re.I),re.compile(r'LunaRune64\.xlsx',re.I)]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in {'.html','.js','.json','.py','.md','.yml','.yaml'}: continue
    try: s=p.read_text(encoding='utf-8')
    except Exception: continue
    for rx in legacy:
        for m in rx.finditer(s): add('legacy_reference',p,m.group(0),s.count('\n',0,m.start())+1)
attr=re.compile("(?:src|href)=[\\\"']([^\\\"']+)[\\\"']",re.I)
for p in root.rglob('*.html'):
    try: s=p.read_text(encoding='utf-8')
    except Exception: continue
    for m in attr.finditer(s):
        u=m.group(1).strip()
        if not u or u.startswith(('#','http://','https://','mailto:','tel:','data:','javascript:','{{','${')): continue
        path=urlparse(u).path
        if not path: continue
        target=(root/path.lstrip('/')) if path.startswith('/') else (p.parent/path)
        if not target.exists(): add('missing_local_reference',p,u,s.count('\n',0,m.start())+1)
print(json.dumps({'root':str(root),'finding_count':len(findings),'findings':findings},ensure_ascii=False,indent=2))
