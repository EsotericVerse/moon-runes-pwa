# Example: Remove Legacy runes64 Projection Safely
1 search every live `runes64` reference
2 identify canonical replacement (`runes66`/current core projection)
3 update HTML/JS/Python consumers
4 update service-worker/manifest references
5 validate JSON/load behavior
6 smoke-test rune list/draw/result/search
7 delete only after migration
8 re-search for zero live references
If README/FAQ still calls old file authoritative, route semantic defect through KM governance too.
