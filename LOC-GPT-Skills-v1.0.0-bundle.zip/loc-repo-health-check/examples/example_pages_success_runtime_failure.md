# Example: Successful Deploy but Runtime Failure
Observed: deployment succeeds; `index.html` responds; `runes.html` fetches deleted legacy JSON.
Conclusion: Git/deployment healthy; static/data/runtime failed; model boundary possibly stale projection; severity H2/H3 depending on core-flow impact.
