---
name: loc-repo-health-check
description: Audit and safely repair the LOC moon-runes-pwa repository across Git, deployment, static/runtime integrity, PWA/cache, data projections, API/search, and LOC Language System Model boundaries without regressing current main.
---

# LOC Repo Health Check

**Skill version:** 1.0.0  
**Theory baseline:** LOC Language System Model / Canon 1.0 generation

## Purpose
Audit operational integrity of `EsotericVerse/moon-runes-pwa` while respecting current LOC model/data governance. A successful deployment does not prove system health.

Use for repo health, GitHub/PR merge blockers, deployment/Cloudflare/Render/runtime, broken links/files/imports, PWA/service-worker/cache, API/search failures, memory regressions, projection migration, and verifying Base66/Context/Graph/Algorithm/Evolution connections.

Semantic Canon decisions belong primarily to `loc-km-governance`; this skill verifies repository implementation of those decisions.

## LOC-aware Repository Model
`Canon/Mother Data → Registries/Core Projection → API/Search/Algorithms → UI/Agent/Skill Consumers`

Semantic domains: `runes`, `context`, `music`, `literary`, `media`, `governance`, `knowledge`, `evolution`, `global`.
LOC1–8 may remain human-facing/legacy compatibility metadata, but new backend coupling should use semantic domains.

## Repository Baseline
Default repo `EsotericVerse/moon-runes-pwa`; default branch `main`; primary public site `loc.lo3rwang.cc`.

Expected current principles (verify current main): `LunaRune66.xlsx` mother source; runtime JSON=projection; `data/json/` role folders; `card_api/` active API/search; `engine/` experimental semantic/vector work; Graph ownership=Context; Graph retrieval/traversal may=Knowledge; Evolution consumes temporal projections.

## Health Layers
1 Git State
2 CI State
3 Deployment State
4 Static Integrity
5 Data Integrity
6 Runtime Integrity
7 API/Search Integrity
8 PWA Integrity
9 Functional Integrity
10 Model Boundary Integrity

Never collapse them into one status.

## Workflow
### 1. Inspect current repository truth
Check current main/ref, relevant PRs, recent workflow/deployment evidence and changed files. Never merge stale content over newer main merely to close a PR.

### 2. Determine affected layers/domains
Map symptom to technical layer + semantic domain.

### 3. Static reference graph
Check HTML/CSS/JS/Python/manifest/service-worker references for missing targets, stale renamed/deleted files, case mismatch, duplicate legacy projections, path errors, old JSON/JS names and stale docs links.

### 4. Data projection integrity
Check JSON syntax/schema expectations; `LunaRune66.xlsx` authority references; stale `runes64`/`LunaRune64` runtime dependencies; duplicated projections; registry references/stable IDs.
A source-of-truth defect is governance; a broken consumer path is repo health; report both if applicable.

### 5. JavaScript/frontend runtime
Check script existence, syntax/module mode, globals/DOM IDs, async/fetch failure handling, repeated large JSON loads, duplicate in-memory data, fallback behavior.

### 6. Python/API/search
Check imports/startup/routes/file loading; repeated whole-corpus loads; per-request rebuilds; caching; memory amplification from duplicated JSON/dataframes/embeddings; model initialization per request; endpoint failure/fallback. Separate baseline memory from request-triggered spikes.

### 7. PWA/service worker
Check registration, scope, cache name, precache, activate cleanup, fetch strategy, stale deleted assets. See `resources/pwa_checks.md`.

### 8. Functional smoke test by current public surfaces
Prefer current major surfaces: `/`, `runes.html`, `context.html`, `search.html`, `evolution.html`, `governance.html`, `loc2-game.html`, `lo3rwang.html`, tutorials when relevant, plus linked draw/result pages and API routes actually consumed.
Do not flag absence of a legacy v0.1 page merely because old skill expected it.

### 9. Model boundary check
Verify mother data outranks projections; generated/search do not write back as Canon; Graph semantics=context; Graph RAG traversal/retrieval=knowledge where applicable; temporal trend/trajectory=evolution; raw corpus separate from governance interpretation; LunaRunes reference implementation not synonymous with LOC itself.

### 10. Minimal safe repair
For legacy-file deletion: find all consumers → migrate → validate replacement → update SW/cache/docs → delete → smoke test → re-search for zero live references.

### 11. Verification report
Report exactly what was tested.

## Severity
- **H0** Healthy
- **H1** Cosmetic / maintenance debt
- **H2** Functional risk / partial feature failure
- **H3** Blocking runtime/deploy/core-flow defect
- **H4** Integrity defect that can corrupt authoritative data, silently regress model semantics, or repeatedly destabilize production resources

## Performance / Memory Rule
Treat resource exhaustion as health. Prefer single projection reuse, lazy/on-demand loads, bounded result sets, cached precomputed indexes, no duplicate full-corpus copies per request, no model/embedding initialization per request, streaming/pagination for large outputs. Do not optimize by destroying provenance/source evidence.

## Automated First Pass
With local checkout run `python scripts/repo_health.py <repo-root>`. It checks common stale paths, broken local HTML links/scripts, JSON parse errors and selected legacy references. It does not replace browser/runtime/deployment testing.

## Output Contract
Report Git/PR; deployment/CI; static/data/runtime/API/PWA; model-boundary findings; severity; fixes; verified smoke tests; remaining unverified risks. Follow `schemas/repo_health_result.schema.json` where practical. Separate **verified**, **inferred**, **not tested**.

## Action Style
When direct fixes are authorized, execute safe changes without redundant confirmation. Protect current main and authoritative data.

## References
- `resources/repo_architecture.md`
- `resources/runtime_layers.md`
- `resources/pwa_checks.md`
- `examples/example_legacy_projection_removal.md`
