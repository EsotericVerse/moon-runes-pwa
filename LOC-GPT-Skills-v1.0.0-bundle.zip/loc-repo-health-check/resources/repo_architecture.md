# LOC Repository Architecture Reference
Conceptual flow: `Canon/Mother Data → Registry/Core Projection → Search/Generated/Algorithms → API/UI/Analysis/Skills`.
Downstream layers are consumers/projections, not authority.

Expected current areas (verify main): `LunaRune66.xlsx`; `data/json/core/`; `registries/`; `search/`; `generated/`; `archive/`; `experimental/`; `card_api/`; `engine/`; `tools/`; frontend `js/`/`css/`; media assets.

Ownership: runes=Base66 semantics/draw; context=relation/event/Graph semantics; knowledge=retrieval/validation/algorithms/RAG/Graph traversal; evolution=time/period/trend/trajectory. LOC1–8 are not preferred new backend ownership keys.
