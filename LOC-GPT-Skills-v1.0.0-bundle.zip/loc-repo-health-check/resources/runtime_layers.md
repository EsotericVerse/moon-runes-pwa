# Runtime Verification Layers
- Build: pipeline accepts source
- HTTP: host responds
- Static integrity: local resources exist
- Data integrity: projections parse/use current sources
- Runtime: JS/Python executes
- API/search: requests complete with bounded resources/fallbacks
- Functional: intended user flow finishes
- PWA: service worker installs/updates without stale traps
- Model integrity: runtime may still be semantically wrong if it loads stale projections or violates authority
