# PWA / Service Worker Check Reference
Check registration path/scope/cache version/precache URLs/activate cleanup/fetch strategy/navigation fallback.
`cache.addAll()` can abort install when any required asset fails.

Recommendations: frequently changing HTML/JSON/API-facing content network-first or bounded stale-while-revalidate; stable icons/images cache-first; do not blindly precache large generated corpora; after major dependency migration bump cache once after paths are coherent.

Migration checklist:
- [ ] no deleted legacy file in precache
- [ ] replacement reachable
- [ ] offline-critical assets intentional
- [ ] activate cleanup handles old versions
- [ ] old clients can update without reload loop
